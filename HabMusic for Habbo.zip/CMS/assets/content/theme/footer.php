<?php if("$yilmazev" == "https://github.com/yilmazev"){ echo "$footer"; } else { echo "<footer><div class='copyright'><div class='container'><div class='row'><div class='col-6'><p class='text-left float-left'><span class='text-highlight'>License Error</span></p></div></div></div></div></footer>"; } ?>
<style>
.text-highlight a {
	color: #fff;
	text-decoration: none;
}
</style>
<script src="/assets/content/scripts/sweetalert2.all.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="/assets/content/scripts/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="/assets/content/scripts/jquery.swipebox.js"></script>
<script src="/assets/content/scripts/main.js"></script>
        <script type="text/javascript">
            ;( function( $ ) {

                $( '.swipebox' ).swipebox( {
                    useCSS : true, 
                    useSVG : true, 
                    initialIndexOnArray : 0, 
                    hideCloseButtonOnMobile : false, 
                    removeBarsOnMobile : false, 
                    hideBarsDelay : 3000, 
                    videoMaxWidth : 1140, 
                    beforeOpen: function() {}, 
                    afterOpen: null, 
                    afterClose: function() {}, 
                    loopAtEnd: false 
                } );

            } )( jQuery );
        </script>
</body>
</html>