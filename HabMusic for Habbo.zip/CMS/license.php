<?php

###############################################################################
#                            www.HabMusic.de Clone                            #
#                              Powered by Habbink                             #
#                                                                             #
#               Developer by Yılmaz EV (Discord: Hugoyin#7116)                #
###############################################################################

require ('global.php');

if("$yilmazev" == "https://github.com/yilmazev")
{
	echo "
	License: Active
	";
}

else
{
	echo "
	License: Not Active
	";
}

?>