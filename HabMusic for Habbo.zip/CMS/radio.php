<?php

###############################################################################
#                            www.HabMusic.de Clone                            #
#                              Powered by Habbink                             #
#                                                                             #
#               Developer by Yılmaz EV (Discord: Hugoyin#7116)                #
###############################################################################

require ('global.php');

include "assets/content/theme/header.php";
include "assets/content/theme/menu.php";
include "assets/content/theme/radio.php"; 
include "assets/content/theme/footer.php"; 

?>
