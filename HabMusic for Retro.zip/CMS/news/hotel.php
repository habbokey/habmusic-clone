<?php

require ('../global.php');

include "../assets/content/theme/header.php";
include "../assets/content/theme/menu.php";
include "../assets/content/theme/news/hotel.php";
include "../assets/content/theme/footer.php";
?>
