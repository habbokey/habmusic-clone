<title><?php echo "$title";?> - <?php echo $lang[63]; ?></title>
<main class="container">
    <div class="content">
        <div class="row">
            <div class="col-lg-12 col-md-12">
            </div>
         
            <div class="col-lg-8 col-md-12 content-left">
                
                <div class="content-box">
            <div class="content-header">
                <h1><?php echo $lang[63]; ?></h1>
            </div>
            <div class="content-body"><div class="alert alert-danger schedules-none" role="alert"><?php echo $lang[64]; ?></div></div></div><div class="content-box">
            </div></div>
            <div class="col-lg-4 col-md-12 content-right">
                <div class="content-box">
    <div class="content-header">
        <h1><?php echo $lang[65]; ?></h1>
    </div>
    <div class="content-body">
        <img src="/assets/content/images/file_238.png" alt="radio.png" align="left" style="margin-right: 10px;margin-bottom: 0px;padding-top: 20px;"border="0">
<div style="margin-top:4px;">
<?php echo $lang[66]; ?>
<div style="height: 9px;"></div>
</div>
    </div>
</div>
</div>
            </div>
        </div>
    </div>
</main>