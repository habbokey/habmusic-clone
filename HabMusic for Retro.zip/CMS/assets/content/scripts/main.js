$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip({html: true});
    
    $('.small-slider').slick({
        slidesToShow: 9,
        slidesToScroll: 1,
        variableWidth: true,
        infinite: false,
        swipeToSlide: true,
		touchThreshold: 50000,
        prevArrow: '<div class="sm-sld-left"><i class="fas fa-chevron-left"></i></div>',
        nextArrow: '<div class="sm-sld-right"><i class="fas fa-chevron-right"></i></div>',
    });
	
	$('.image-slider').slick({
        slidesToShow: 9,
        slidesToScroll: 1,
        infinite: false,
        swipeToSlide: true,
        prevArrow: '<div class="sm-sld-left"><i class="fas fa-chevron-left"></i></div>',
        nextArrow: '<div class="sm-sld-right"><i class="fas fa-chevron-right"></i></div>',
    });
    
    var habmusicPlayer = document.querySelector('#habmusic-player');
    var footer = document.querySelector('footer');
    
    function checkOffset() {
        function getRectTop(el) {
            var rect = el.getBoundingClientRect();
            return rect.top;
        }
        
        if ((getRectTop(habmusicPlayer) + document.body.scrollTop) + habmusicPlayer.offsetHeight >=
            (getRectTop(footer) + document.body.scrollTop - 10))
            habmusicPlayer.style.position = 'relative';
        if (document.body.scrollTop + window.innerHeight < (getRectTop(footer) + document.body.scrollTop))
            habmusicPlayer.style.position = 'fixed';
    }
    
    document.addEventListener("scroll", function () {
        checkOffset();
    });
    
    document.querySelector('#cookies').addEventListener('click', function () {
        document.querySelector('#cookies').style.display = 'none';
    });
	
	$("#emojionearea1").emojioneArea({
  	
		pickerPosition: "right",
    	tonesStyle: "bullet",
		events: {
         	keyup: function (editor, event) {
           		console.log(editor.html());
           		console.log(this.getText());
        	}
    	}
	});
	
	$('input[type="file"]').change(function(e){
        var fileName = e.target.files[0].name;
        $('.custom-file-label').html(fileName);
    });
	
	;( function( $ ) {

                $( '.swipebox' ).swipebox( {
                    useCSS : true, 
                    useSVG : true, 
                    initialIndexOnArray : 0, 
                    hideCloseButtonOnMobile : false, 
                    removeBarsOnMobile : false, 
                    hideBarsDelay : 3000, 
                    videoMaxWidth : 1140, 
                    beforeOpen: function() {}, 
                    afterOpen: null, 
                    afterClose: function() {}, 
                    loopAtEnd: false 
                } );

            } )( jQuery );
});